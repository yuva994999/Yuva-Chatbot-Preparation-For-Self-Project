package oakbot.bot;

/**
 * Represents an action to perform in response to a chat message.
 * @author Michael Angstadt
 */
public interface ChatAction {
	//empty
}
