java -cp MajBot.jar bot.Main
